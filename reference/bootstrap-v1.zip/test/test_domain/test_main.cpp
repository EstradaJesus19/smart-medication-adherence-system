#include <Adherence.h>
#include <Simulation.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#ifdef STANDALONE_TEST
#define CHECK(expression) do { if (!(expression)) { std::fprintf(stderr, "%s:%d: %s\n", __FILE__, __LINE__, #expression); std::exit(1); } } while (0)
#define RUN_TEST(function) do { function(); std::puts(#function " PASS"); } while (0)
#else
#include <unity.h>
#define CHECK(expression) TEST_ASSERT_TRUE(expression)
void setUp() {}
void tearDown() {}
#endif
using namespace adherence;
struct Log final : EventLogger {
    Event events[128]{};
    size_t used = 0;
    void log(const Event& e) override { CHECK(used < 128); events[used++] = e; }
    unsigned count(const char* type) const {
        unsigned n = 0;
        for (size_t i = 0; i < used; ++i) if (std::strcmp(events[i].type, type) == 0) ++n;
        return n;
    }
};
struct Outputs final : ReminderController {
    State state = State::Idle;
    unsigned warnings = 0;
    void show(State s, uint8_t) override { state = s; }
    void warn(uint8_t) override { ++warnings; }
};
struct Fixture { Log log; Outputs output; MedicationStateMachine sm{log, output}; };
void test_correct_access() {
    Fixture f;
    CHECK(f.sm.start(2, 100, 100));
    f.sm.lidChanged(2, true, 101);
    f.sm.tick(102);
    CHECK(f.sm.state() == State::Verifying);
    f.sm.tick(103);
    CHECK(f.log.count("ACCESS_CONFIRMED") == 1);
    CHECK(f.sm.state() == State::Idle);
    CHECK(f.output.state == State::Idle);
    CHECK(f.log.events[f.log.used - 1].doseTime == 100);
}
void test_wrong_then_correct() {
    Fixture f;
    f.sm.start(2, 100, 100);
    f.sm.lidChanged(3, true, 101);
    CHECK(f.log.count("WRONG_COMPARTMENT") == 1);
    CHECK(f.output.warnings == 1);
    CHECK(f.sm.state() == State::Reminder);
    f.sm.lidChanged(2, true, 102);
    f.sm.tick(104);
    CHECK(f.log.count("ACCESS_CONFIRMED") == 1);
}
void test_missed_once() {
    Fixture f;
    f.sm.start(2, 100, 100);
    f.sm.tick(159);
    CHECK(f.sm.state() == State::Reminder);
    f.sm.tick(160);
    f.sm.tick(200);
    CHECK(f.log.count("MISSED") == 1);
    CHECK(f.sm.state() == State::Idle);
}
void test_repeat_needs_new_edge() {
    Fixture f;
    f.sm.start(2, 100, 100);
    f.sm.lidChanged(2, true, 101);
    f.sm.tick(103);
    f.sm.lidChanged(2, true, 104);
    CHECK(f.log.count("REPEATED_ACCESS") == 0);
    f.sm.lidChanged(2, false, 105);
    f.sm.lidChanged(2, true, 106);
    CHECK(f.log.count("REPEATED_ACCESS") == 1);
    CHECK(f.log.count("ACCESS_CONFIRMED") == 1);
}
void test_brief_open_retries() {
    Fixture f;
    f.sm.start(2, 100, 100);
    f.sm.lidChanged(2, true, 101);
    f.sm.lidChanged(2, false, 102);
    f.sm.tick(104);
    CHECK(f.sm.state() == State::Reminder);
    CHECK(f.log.count("BRIEF_OPEN") == 1);
    CHECK(f.log.count("ACCESS_CONFIRMED") == 0);
    f.sm.lidChanged(2, true, 105);
    f.sm.tick(107);
    CHECK(f.log.count("ACCESS_CONFIRMED") == 1);
}
void test_timeout_wins_verification_boundary() {
    Fixture f;
    f.sm.start(2, 100, 100);
    f.sm.lidChanged(2, true, 158);
    f.sm.tick(160);
    CHECK(f.log.count("MISSED") == 1);
    CHECK(f.log.count("ACCESS_CONFIRMED") == 0);
    f.sm.lidChanged(2, false, 161);
    f.sm.lidChanged(2, true, 162);
    CHECK(f.log.count("UNSCHEDULED_OPEN") == 1);
}
void test_already_open_requires_reopening() {
    Fixture f;
    f.sm.lidChanged(2, true, 90);
    f.sm.start(2, 100, 100);
    f.sm.tick(103);
    CHECK(f.sm.state() == State::Reminder);
    CHECK(f.log.count("CLOSE_THEN_REOPEN") == 1);
    f.sm.lidChanged(2, false, 104);
    f.sm.lidChanged(2, true, 105);
    f.sm.tick(107);
    CHECK(f.log.count("ACCESS_CONFIRMED") == 1);
}
void test_invalid_and_conflicting_doses() {
    Fixture f;
    CHECK(!f.sm.start(0, 100, 100));
    CHECK(!f.sm.start(5, 100, 100));
    CHECK(!f.sm.start(1, 101, 100));
    CHECK(f.sm.start(2, 100, 100));
    CHECK(!f.sm.start(3, 101, 101));
    CHECK(f.sm.activeCompartment() == 2);
    CHECK(f.log.count("DOSE_CONFLICT") == 1);
    f.sm.lidChanged(255, true, 102);
    CHECK(f.sm.state() == State::Reminder);
}
void test_scheduler_daily_deduplication() {
    Fixture f;
    MedicationScheduler scheduler;
    CHECK(scheduler.add({8, 0, 2}));
    scheduler.poll(28799, f.sm);
    CHECK(f.log.used == 0);
    scheduler.poll(28800, f.sm);
    scheduler.poll(28801, f.sm);
    CHECK(f.log.count("REMINDER_STARTED") == 1);
    f.sm.tick(28860);
    scheduler.poll(kDay + 28800, f.sm);
    CHECK(f.log.count("REMINDER_STARTED") == 2);
}
void test_scheduler_validation() {
    MedicationScheduler scheduler;
    CHECK(!scheduler.add({24, 0, 1}));
    CHECK(!scheduler.add({8, 60, 1}));
    CHECK(!scheduler.add({8, 0, 0}));
    CHECK(scheduler.add({8, 0, 1}));
    CHECK(!scheduler.add({8, 0, 2}));
    for (uint8_t hour = 9; hour < 16; ++hour) CHECK(scheduler.add({hour, 0, 1}));
    CHECK(!scheduler.add({16, 0, 1}));
}
void test_late_poll_and_midnight() {
    Fixture f;
    MedicationScheduler scheduler;
    scheduler.add({0, 0, 1});
    scheduler.poll(60, f.sm);
    scheduler.poll(61, f.sm);
    CHECK(f.log.count("MISSED") == 1);
    scheduler.poll(kDay, f.sm);
    CHECK(f.sm.state() == State::Reminder);
    CHECK(f.log.count("REMINDER_STARTED") == 1);
}
void test_unsorted_schedule_preserves_active_dose() {
    Fixture f;
    MedicationScheduler scheduler;
    scheduler.add({20, 0, 4});
    scheduler.add({8, 0, 2});
    scheduler.poll(20 * 3600, f.sm);
    CHECK(f.sm.activeCompartment() == 4);
    CHECK(f.sm.state() == State::Reminder);
    CHECK(f.log.count("MISSED") == 1);
    CHECK(f.log.count("DOSE_CONFLICT") == 0);
    CHECK(f.log.events[f.log.used - 1].doseTime == 8 * 3600);
}
void test_new_dose_clears_repeat_flag() {
    Fixture f;
    f.sm.start(2, 100, 100);
    f.sm.lidChanged(2, true, 101);
    f.sm.tick(103);
    f.sm.lidChanged(2, false, 104);
    f.sm.start(2, 200, 200);
    f.sm.lidChanged(2, true, 201);
    f.sm.tick(203);
    CHECK(f.log.count("REPEATED_ACCESS") == 0);
    CHECK(f.log.count("ACCESS_CONFIRMED") == 2);
}
struct TextCapture final : TextOutput {
    char text[16384]{};
    void line(const char* row) override {
        CHECK(std::strlen(text) + std::strlen(row) + 2 < sizeof(text));
        std::strcat(text, row); std::strcat(text, "\n");
    }
};
void send(Simulation& sim, const char* text) { while (*text) sim.feed(*text++); }
void test_serial_workflow_and_validation() {
    TextCapture out;
    Simulation sim(out);
    sim.begin();
    send(sim, "dose 2\r\nopen 3\nopen 2\nadvance 2\nstatus\n");
    CHECK(std::strstr(out.text, "WRONG_COMPARTMENT"));
    CHECK(std::strstr(out.text, "ACCESS_CONFIRMED"));
    CHECK(std::strstr(out.text, "state=IDLE active=0"));
    send(sim, "dose -1\nadvance 9999999999999999999\nopen 2 extra\n");
    CHECK(std::strstr(out.text, "# error: invalid"));
    for (int i = 0; i < 100; ++i) sim.feed('x');
    send(sim, "\nstatus\n");
    CHECK(std::strstr(out.text, "line too long; discarded"));
}
void test_advance_visits_scheduled_window() {
    TextCapture out;
    Simulation sim(out);
    sim.begin();
    send(sim, "advance 120\n");
    CHECK(std::strstr(out.text, "28800,REMINDER_STARTED,2,28800"));
    CHECK(std::strstr(out.text, "28860,MISSED,2,28800"));
}
int main() {
#ifndef STANDALONE_TEST
    UNITY_BEGIN();
#endif
    RUN_TEST(test_correct_access);
    RUN_TEST(test_wrong_then_correct);
    RUN_TEST(test_missed_once);
    RUN_TEST(test_repeat_needs_new_edge);
    RUN_TEST(test_brief_open_retries);
    RUN_TEST(test_timeout_wins_verification_boundary);
    RUN_TEST(test_already_open_requires_reopening);
    RUN_TEST(test_invalid_and_conflicting_doses);
    RUN_TEST(test_scheduler_daily_deduplication);
    RUN_TEST(test_scheduler_validation);
    RUN_TEST(test_late_poll_and_midnight);
    RUN_TEST(test_unsorted_schedule_preserves_active_dose);
    RUN_TEST(test_new_dose_clears_repeat_flag);
    RUN_TEST(test_serial_workflow_and_validation);
    RUN_TEST(test_advance_visits_scheduled_window);
#ifndef STANDALONE_TEST
    return UNITY_END();
#else
    return 0;
#endif
}
