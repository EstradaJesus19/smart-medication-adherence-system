# Experimental data

No experimental measurements are included yet. Never label simulator output as
hardware data. Suggested layout: `data/<run-id>/raw.txt`, `events.csv`,
`metadata.md`, and externally observed trial labels. Keep raw logs untouched.

The simulator prints this CSV header:

```csv
time_s,event,compartment,dose_time_s,state,clock_source,evidence
```

| Column | Meaning |
| --- | --- |
| time_s | Simulation seconds since artificial day 0; not Unix/UTC time |
| event | Stable uppercase event name from the FSM |
| compartment | 1–4; 0 reserved for not applicable |
| dose_time_s | Due time of the contextual occurrence; see context rules below |
| state | State at event emission, before any subsequent transition |
| clock_source | `simulated` in this bootstrap |
| evidence | `lid_only`, including access-confirmation events |

Output lines beginning with `#` are comments and must be removed for CSV import.
Do not add terminal prompts or echoed input to cleaned CSV. Avoid concatenating
multiple restart sessions without preserving run boundaries. Use a CSV reader
and validate column counts when preparing analysis.

For active-dose events, dose context is the active due time. A conflict row uses
the rejected occurrence's due time. For idle lid events, context is zero. Repeated
access references the last confirmed occurrence for that compartment. Zero may
also represent a legitimate scheduled occurrence at simulation day 0 midnight;
interpret it together with event type and state. Join occurrences using run ID,
compartment and due time; manually injecting multiple doses for the same
compartment at the same second is outside the experimental protocol.

Metadata per run: run ID; date; operator initials if useful; Git revision (or
“uncommitted bootstrap”); firmware environment; hardware vs simulation; board and
module versions; schedule; window and verification/debounce durations; clock
source; initial lid states; exact commands/procedure; test case; ground truth;
expected outcome; observed outcome; pass/fail; anomalies. Do not record patient
names or actual medication details for these bench experiments.
