#include "Adherence.h"

namespace adherence {
namespace { bool valid(uint8_t c) { return c >= 1 && c <= kCompartments; } }
const char* stateName(State state) {
    switch (state) {
    case State::Idle: return "IDLE";
    case State::Reminder: return "REMINDER";
    case State::Verifying: return "VERIFYING";
    }
    return "UNKNOWN";
}
bool SimulatedLids::isOpen(uint8_t c) const { return valid(c) && open_[c - 1]; }
bool SimulatedLids::set(uint8_t c, bool open) {
    if (!valid(c)) return false;
    open_[c - 1] = open;
    return true;
}
void MedicationStateMachine::emit(const char* type, uint8_t c, Seconds now) {
    logger_.log({now, type, c, state_ == State::Idle ? 0 : due_, state_});
}
void MedicationStateMachine::transition(State state) {
    state_ = state;
    reminder_.show(state_, active_);
}
bool MedicationStateMachine::start(uint8_t c, Seconds due, Seconds now) {
    if (!valid(c) || due > now) return false;
    // Expire the old window before deciding whether this occurrence conflicts.
    tick(now);
    if (now - due >= kWindow) {
        logger_.log({now, "MISSED", c, due, state_});
        return true;
    }
    if (state_ != State::Idle) {
        logger_.log({now, "DOSE_CONFLICT", c, due, state_});
        return false;
    }
    active_ = c;
    due_ = due;
    confirmed_[c - 1] = false;
    transition(State::Reminder);
    emit("REMINDER_STARTED", c, now);
    // Already-open lids never confirm a newly started occurrence.
    if (open_[c - 1]) emit("CLOSE_THEN_REOPEN", c, now);
    return true;
}
void MedicationStateMachine::tick(Seconds now) {
    if (state_ == State::Idle) return;
    // Timeout wins at the exact deadline, including during verification.
    if (now >= due_ && now - due_ >= kWindow) {
        emit("MISSED", active_, now);
        active_ = 0;
        transition(State::Idle);
    } else if (state_ == State::Verifying && now >= openedAt_ &&
               now - openedAt_ >= kVerify) {
        confirmed_[active_ - 1] = true;
        confirmedDue_[active_ - 1] = due_;
        emit("ACCESS_CONFIRMED", active_, now);
        active_ = 0;
        transition(State::Idle);
    }
}
void MedicationStateMachine::lidChanged(uint8_t c, bool open, Seconds now) {
    if (!valid(c)) return;
    tick(now);
    if (open_[c - 1] == open) return; // Duplicate levels are not new edges.
    open_[c - 1] = open;
    emit(open ? "LID_OPEN" : "LID_CLOSED", c, now);
    if (!open) {
        if (state_ == State::Verifying && c == active_) {
            emit("BRIEF_OPEN", c, now);
            transition(State::Reminder);
        }
        return;
    }
    if (confirmed_[c - 1]) {
        logger_.log({now, "REPEATED_ACCESS", c, confirmedDue_[c - 1], state_});
        reminder_.warn(c);
    }
    if (state_ == State::Idle) {
        if (!confirmed_[c - 1]) emit("UNSCHEDULED_OPEN", c, now);
    } else if (c != active_) {
        emit("WRONG_COMPARTMENT", c, now);
        reminder_.warn(c);
    } else {
        openedAt_ = now;
        transition(State::Verifying);
        emit("VERIFICATION_STARTED", c, now);
    }
}
bool MedicationScheduler::add(MedicationSchedule e) {
    if (e.hour > 23 || e.minute > 59 || !valid(e.compartment) || count_ == kCapacity)
        return false;
    const Seconds seconds = e.hour * 3600U + e.minute * 60U;
    for (size_t i = 0; i < count_; ++i) {
        const Seconds other = entries_[i].hour * 3600U + entries_[i].minute * 60U;
        const Seconds gap = seconds > other ? seconds - other : other - seconds;
        if (gap < kWindow || kDay - gap < kWindow) return false;
    }
    entries_[count_++] = e;
    return true;
}
void MedicationScheduler::poll(Seconds now, MedicationStateMachine& machine) {
    const Seconds day = now / kDay;
    for (size_t i = 0; i < count_; ++i) {
        const Seconds due = day * kDay + entries_[i].hour * 3600U + entries_[i].minute * 60U;
        if (now >= due && (!seen_[i] || day > lastDay_[i])) {
            seen_[i] = true;
            lastDay_[i] = day; // A conflict is logged once, never retried silently.
            machine.start(entries_[i].compartment, due, now);
        }
    }
}
} // namespace adherence
