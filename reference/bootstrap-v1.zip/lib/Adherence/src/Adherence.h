#pragma once
#include <cstddef>
#include <cstdint>

namespace adherence {
using Seconds = uint64_t;
constexpr uint8_t kCompartments = 4;
constexpr Seconds kDay = 86400;
constexpr Seconds kWindow = 60; // Accelerated demo; choose a study value later.
constexpr Seconds kVerify = 2;
enum class State { Idle, Reminder, Verifying };
const char* stateName(State state);
struct Event {
    Seconds time;
    const char* type;
    uint8_t compartment; // 1..4; 0 = not applicable
    Seconds doseTime;
    State state;
};
class EventLogger {
public:
    virtual ~EventLogger() = default;
    virtual void log(const Event& event) = 0;
};
class ReminderController {
public:
    virtual ~ReminderController() = default;
    virtual void show(State state, uint8_t compartment) = 0;
    virtual void warn(uint8_t compartment) = 0;
};
// A future reed-switch adapter publishes DEBOUNCED levels through this port.
class LidSensor {
public:
    virtual ~LidSensor() = default;
    virtual bool isOpen(uint8_t compartment) const = 0;
};
class SimulatedLids final : public LidSensor {
public:
    bool isOpen(uint8_t compartment) const override;
    bool set(uint8_t compartment, bool open);
private:
    bool open_[kCompartments]{};
};
class MedicationStateMachine {
public:
    MedicationStateMachine(EventLogger& logger, ReminderController& reminder)
        : logger_(logger), reminder_(reminder) {}
    bool start(uint8_t compartment, Seconds due, Seconds now);
    void tick(Seconds now);
    void lidChanged(uint8_t compartment, bool open, Seconds now);
    State state() const { return state_; }
    uint8_t activeCompartment() const { return active_; }
private:
    void emit(const char* type, uint8_t compartment, Seconds now);
    void transition(State state);
    EventLogger& logger_;
    ReminderController& reminder_;
    State state_ = State::Idle;
    uint8_t active_ = 0;
    Seconds due_ = 0;
    Seconds openedAt_ = 0;
    bool open_[kCompartments]{};
    bool confirmed_[kCompartments]{};
    Seconds confirmedDue_[kCompartments]{};
};
struct MedicationSchedule { uint8_t hour; uint8_t minute; uint8_t compartment; };
class MedicationScheduler {
public:
    static constexpr size_t kCapacity = 8;
    bool add(MedicationSchedule entry);
    void poll(Seconds now, MedicationStateMachine& machine);
private:
    MedicationSchedule entries_[kCapacity]{};
    Seconds lastDay_[kCapacity]{};
    bool seen_[kCapacity]{};
    size_t count_ = 0;
};
} // namespace adherence
