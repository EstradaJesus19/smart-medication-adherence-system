#include "Simulation.h"
#include <cstdio>
#include <cstring>

namespace adherence {
void CsvLogger::log(const Event& e) {
    char row[160];
    std::snprintf(row, sizeof(row), "%llu,%s,%u,%llu,%s,simulated,lid_only",
                  static_cast<unsigned long long>(e.time), e.type, e.compartment,
                  static_cast<unsigned long long>(e.doseTime), stateName(e.state));
    out_.line(row);
}
void SimulatedReminder::show(State state, uint8_t c) {
    char row[80];
    std::snprintf(row, sizeof(row), "# output state=%s compartment=%u", stateName(state), c);
    out_.line(row);
}
void SimulatedReminder::warn(uint8_t c) {
    char row[80];
    std::snprintf(row, sizeof(row), "# warning compartment=%u", c);
    out_.line(row);
}
Simulation::Simulation(TextOutput& out)
    : out_(out), logger_(out), reminder_(out), machine_(logger_, reminder_) {
    scheduler_.add({8, 0, 2});
    scheduler_.add({20, 0, 4});
}
void Simulation::begin() {
    out_.line("# SIMULATION ONLY: manual clock; day 0 07:59:00; window=60s; verify=2s");
    out_.line("time_s,event,compartment,dose_time_s,state,clock_source,evidence");
    out_.line("# commands: dose 1..4 | open 1..4 | close 1..4 | advance 1..86400 | status | help");
}
void Simulation::sampleLids() {
    for (uint8_t c = 1; c <= kCompartments; ++c) {
        const bool open = lids_.isOpen(c);
        if (open != sampled_[c - 1]) {
            sampled_[c - 1] = open;
            machine_.lidChanged(c, open, now_);
        }
    }
}
void Simulation::feed(char byte) {
    if (byte == '\r') return;
    if (byte == '\n') {
        if (overflow_) out_.line("# error: line too long; discarded");
        else { buffer_[used_] = '\0'; command(buffer_); }
        used_ = 0;
        overflow_ = false;
    } else if (used_ + 1 < sizeof(buffer_) && !overflow_) {
        buffer_[used_++] = byte;
    } else overflow_ = true;
}
void Simulation::command(char* line) {
    // Strict bounded parsing: no negative numbers, overflow or trailing tokens.
    char* verb = std::strtok(line, " \t");
    if (!verb) return;
    char* argument = std::strtok(nullptr, " \t");
    char* extra = std::strtok(nullptr, " \t");
    if (!argument && std::strcmp(verb, "help") == 0) {
        out_.line("# dose N | open N | close N | advance SECONDS | status; restart to reset");
        return;
    }
    if (!argument && std::strcmp(verb, "status") == 0) {
        char row[100];
        std::snprintf(row, sizeof(row), "# time_s=%llu state=%s active=%u",
                      static_cast<unsigned long long>(now_), stateName(machine_.state()),
                      machine_.activeCompartment());
        out_.line(row);
        return;
    }
    uint32_t value = 0;
    bool valid = argument && !extra;
    if (argument) for (const char* p = argument; *p; ++p) {
        if (*p < '0' || *p > '9' || value > 86400) { valid = false; break; }
        value = value * 10 + static_cast<uint32_t>(*p - '0');
    }
    if (!valid || value == 0 || value > 86400) {
        out_.line("# error: invalid command or argument"); return;
    }
    if (std::strcmp(verb, "advance") == 0) {
        // Visit every second so an accelerated test cannot skip dose windows.
        for (uint32_t i = 0; i < value; ++i) {
            ++now_;
            machine_.tick(now_);
            scheduler_.poll(now_, machine_);
        }
        return;
    }
    if (value > kCompartments) { out_.line("# error: compartment must be 1..4"); return; }
    const auto c = static_cast<uint8_t>(value);
    if (std::strcmp(verb, "dose") == 0) {
        if (!machine_.start(c, now_, now_)) out_.line("# error: dose rejected; active reminder retained");
    } else if (std::strcmp(verb, "open") == 0 || std::strcmp(verb, "close") == 0) {
        lids_.set(c, std::strcmp(verb, "open") == 0);
        sampleLids();
    } else out_.line("# error: unknown command; use help");
}
} // namespace adherence
