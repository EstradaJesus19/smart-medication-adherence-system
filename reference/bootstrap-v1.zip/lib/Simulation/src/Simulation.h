#pragma once
#include <Adherence.h>

namespace adherence {
class TextOutput {
public:
    virtual ~TextOutput() = default;
    virtual void line(const char* text) = 0;
};
class CsvLogger final : public EventLogger {
public:
    explicit CsvLogger(TextOutput& out) : out_(out) {}
    void log(const Event& event) override;
private:
    TextOutput& out_;
};
class SimulatedReminder final : public ReminderController {
public:
    explicit SimulatedReminder(TextOutput& out) : out_(out) {}
    void show(State state, uint8_t compartment) override;
    void warn(uint8_t compartment) override;
private:
    TextOutput& out_;
};
// Identical adapter used by desktop stdin and the ESP32 serial terminal.
class Simulation {
public:
    explicit Simulation(TextOutput& out);
    void begin();
    void feed(char byte);
private:
    void command(char* line);
    void sampleLids();
    TextOutput& out_;
    CsvLogger logger_;
    SimulatedReminder reminder_;
    MedicationStateMachine machine_;
    MedicationScheduler scheduler_;
    SimulatedLids lids_;
    bool sampled_[kCompartments]{};
    Seconds now_ = 7 * 3600 + 59 * 60; // Simulation day 0, 07:59:00
    char buffer_[80]{};
    size_t used_ = 0;
    bool overflow_ = false;
};
} // namespace adherence
