#include <Simulation.h>
#include <cstdio>

class ConsoleOutput final : public adherence::TextOutput {
public:
    void line(const char* text) override { std::puts(text); }
};
int main() {
    ConsoleOutput output;
    adherence::Simulation simulation(output);
    simulation.begin();
    int byte;
    while ((byte = std::getchar()) != EOF) simulation.feed(static_cast<char>(byte));
    return 0;
}
