#include <Arduino.h>
#include <Simulation.h>

class SerialOutput final : public adherence::TextOutput {
public:
    void line(const char* text) override { Serial.println(text); }
};
SerialOutput output;
adherence::Simulation simulation(output);

void setup() {
    Serial.begin(115200);
    simulation.begin();
}
void loop() {
    // No peripherals or real-time scheduling in this simulation build.
    for (unsigned i = 0; i < 64 && Serial.available(); ++i)
        simulation.feed(static_cast<char>(Serial.read()));
    yield();
}
