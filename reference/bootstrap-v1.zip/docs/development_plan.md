# Development and course roadmap

## Incremental gates

| Course phase | Repository work | Completion gate |
| --- | --- | --- |
| Definition / Introduction | Requirements, scope, target-user context, explicit limits | Instructor brief reconciled; Level 1 scope frozen |
| Previous works | Evidence table and verified references | Representative primary sources compared; claims supported |
| Methodology | Architecture, FSM, protocol and experimental plan | Traceable scenarios; deterministic simulation demonstrated |
| Implementation | RTC, one lid first, then four; LEDs, buzzer, OLED and button | Physical adapters pass hardware tests; no optional feature required |
| Experimental analysis | Raw logs, trial metadata, analysis scripts and figures | Repeatable trials, denominators and failures reported |
| Presentation and video | Paper, slides, concise scripted demonstration | Deliverables match actual measurements and implemented features |

Next hardware integration order: validate board and supply; read RTC and its
validity; integrate one debounced lid; bind output indicators; scale to four lids;
add silence button; run boundary cases and record results. Freeze the working
Level 1 prototype before considering Wi-Fi, enclosure refinement or weight sensing.

## Paper and presentation planning

Tentative eight-page paper allocation (adjust to the instructor's template and
whether references count): Introduction 1 page; Related Works 1; Methodology 2;
Experimental Results 2; Conclusions 0.5; References 1; remaining 0.5 for layout.
Do not fill the Results section with simulated claims about physical performance.

Seven-slide, five-minute pitch: problem/scope (35 s), prior work (35 s), architecture
(50 s), event logic (45 s), prototype/demo (50 s), measured results (55 s), limits
and next steps (30 s). For the 30-second video, show the target reminder, wrong
opening, correct access and its logged outcome. Label accelerated time if used.

## Suggested first-stage Git commits

The bootstrap is supplied as working files. No commits or remote publication are
performed automatically. The following is a reviewable sequence; stage only the
listed paths in each commit and check `git diff --cached` before committing.

1. `chore: scaffold PlatformIO project and repository layout` — `.gitignore`,
   `.vscode/`, `platformio.ini`, `LICENSE`, `include/`, hardware/mechanical/figure
   directory notes. License placeholder explicitly awaits the author's choice.
2. `docs: define MVP requirements and event semantics` — `README.md`,
   `docs/requirements.md`, `docs/system_architecture.md`, `docs/state_machine.md`,
   `docs/bom.md`, `docs/literature_notes.md`, `docs/development_plan.md`, `data/`.
3. `feat: add portable scheduler and access state machine` — `lib/Adherence/`.
4. `feat: add serial and desktop simulation adapters` — `lib/Simulation/`, `src/`.
5. `test: cover access scenarios and add build checks` — `test/`,
   `.github/workflows/`, `docs/test_plan.md`, `docs/validation.md`.

The first commits establish documentation/configuration; the complete executable
appears by commit 4 and tests by commit 5. If the local folder is not already a Git
repository, begin with `git init -b main`. Choose the public license before the
first GitHub publication. No GitHub remote or account is assumed.
