# Test and experimental plan

## Reproducible setup

Run `pio test -e native` for the automated suite. It uses no peripherals and
tests the real domain and serial adapter. Run `pio run -e native -t exec` for
manual commands; the same commands work on the ESP32 serial monitor. Reset before
each independent trial. Serial instructions below start at day 0, 07:59:00.

The bootstrap uses a 60 s dose window and 2 s verification interval. A confirmed
event means access, not ingestion. “Automated” indicates a test exists, not that
a physical experiment has been performed; see `validation.md` for execution.

## Hardware-independent cases

| ID | Scenario / procedure | Expected result | Requirements | Automated function |
| --- | --- | --- | --- | --- |
| T01 | `dose 2; open 2; advance 2` (one command per line) | One ACCESS_CONFIRMED; IDLE; outputs clear | FR-03, FR-05, FR-09 | correct_access |
| T02 | `dose 2; open 3; open 2; advance 2` | Wrong warning; target remains 2; then confirmation | FR-06 | wrong_then_correct |
| T03 | `dose 2; advance 60` | One MISSED at deadline; no repeated outcomes on later ticks | FR-07 | missed_once |
| T04 | T01 then `open 2; close 2; open 2` | Duplicate level ignored; one REPEATED_ACCESS on fresh edge | FR-04, FR-08 | repeat_needs_new_edge |
| T05 | `dose 2; open 2; advance 1; close 2; advance 2` | BRIEF_OPEN, no confirmation, reminder still active | FR-05 | brief_open_retries |
| T06 | `dose 2; advance 58; open 2; advance 2` | MISSED wins at deadline | FR-05, FR-07 | timeout_wins_verification_boundary |
| T07 | `open 2; dose 2; advance 2; close 2; open 2; advance 2` | No confirmation until close/reopen and dwell | FR-11 | already_open_requires_reopening |
| T08 | `dose 0; dose 5; dose 2; dose 3` | Invalid IDs rejected; conflict retains compartment 2 | FR-10, NFR-03 | invalid_and_conflicting_doses |
| T09 | Scheduler polls just before, at and repeatedly after due, then next day | One reminder per occurrence; next day allowed | FR-02 | scheduler_daily_deduplication |
| T10 | Add invalid time/compartment, duplicate slot and ninth entry | Reject each invalid entry; preserve valid entries | FR-01, NFR-03 | scheduler_validation |
| T11 | First poll after expired midnight dose; then next midnight | One missed event; next day's reminder starts | FR-02, FR-07 | late_poll_and_midnight |
| T12 | Confirm then start next dose for same compartment | New confirmation allowed without repeat warning | FR-08 | new_dose_clears_repeat_flag |
| T13 | CRLF, bad numbers, extra tokens, >79-character line | Valid flow works; errors do not corrupt parser; next command works | FR-10 | serial_workflow_and_validation |
| T14 | Fresh launch; `advance 120` | Reminder at 28800; MISSED at 28860 | FR-02, FR-07 | advance_visits_scheduled_window |
| T15 | Capture demo output; discard comment lines and parse CSV | Seven columns; numerical time; clock marked simulated; evidence lid_only | FR-09, NFR-05 | Manual capture review |
| T16 | Add 20:00 then 08:00; first poll at 20:00 | Active compartment 4 retained; expired morning dose marked missed regardless of entry order | FR-01, FR-02, FR-07 | unsorted_schedule_preserves_active_dose |

Names above omit the `test_` prefix. Test implementation:
`test/test_domain/test_main.cpp`. NFR-01 and NFR-08 are checked by native/firmware
builds plus review; NFR-07 by this table and the hardware table below.

## Later hardware tests — not executed

| ID | Procedure | Initial acceptance target | Requirements |
| --- | --- | --- | --- |
| H01 | USB power; RTC schedules two doses; disconnect all network access | Both reminders operate offline and exactly once | FR-02, NFR-06 |
| H02 | Cycle each lid 30 times; include slow motion and switch bounce; timestamp stable edge and output | No duplicate edges; correct compartment; target max 100 ms output latency after stable edge | FR-04, NFR-02 |
| H03 | Repeat T01–T07 on wired device, ten trials each | All expected event sequences; no confirmation on brief openings | FR-05–FR-08, FR-11 |
| H04 | Disconnect RTC / simulate lost time / set valid time | Scheduler inhibited with visible fault until time validated; no fabricated timestamp | FR-12 |
| H05 | Follow a scripted reminder/wrong-lid/silence interaction | Correct LED and text; audible warning; silence button leaves visual reminder and deadline active | FR-03, FR-06, FR-13, NFR-04 |
| H06 | Run 24 h across midnight with controlled schedule | One outcome per eligible occurrence; quantify RTC drift against reference | FR-01, FR-02, FR-09 |
| H07 | Power cycle before due, during reminder and after access | Document volatile-history behavior; no claim of persistent recovery | FR-09; future FR-20 |
| H08 | Leave target open before due; open several lids; lid stuck open/closed | Close/reopen rule holds; incorrect lids cannot confirm target; record detection limitations | FR-04–FR-06, FR-11 |

Before H02 choose a debounce interval from observed switch behavior. Before H05
choose display wording, brightness, buzzer pattern and button debounce. A desk
review is not evidence of usability for elderly users or people with cognitive
decline; report participant population and limitations if a user study is added.

## Measurement and analysis

For each run save untouched raw serial output, a cleaned CSV, and metadata from
`data/README.md`. Use dummy objects, not actual medication. Record externally
observed interaction labels rather than treating the device's own output as
ground truth.

Report counts, denominators, and trial conditions: correct target detections /
correct opening trials, wrong-lid warnings / wrong-lid trials, missed detections /
no-interaction trials, false confirmations / accidental-interaction trials, and
duplicate outcomes / occurrences. Measure hardware response latency with a logic
analyzer or independently timestamped recording; simulation timing cannot measure
physical response. Report min/median/max latency and failures, not just averages.

For the later weight comparison, repeat a controlled matrix of lid-only versus
lid-plus-weight decisions: no removal, removal, return, brief access and enclosure
movement. Record object masses, placement, settling interval and calibration.
Compare false positives/negatives against observed removal. Weight change still
does not establish ingestion. Do not add this experiment until Level 1 works.
