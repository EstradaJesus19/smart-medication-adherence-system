# Requirements baseline — revision 0.1

This baseline separates the intended **Level 1 physical MVP** from the current
**bootstrap simulation**. “Implemented” below refers to simulation/domain logic
unless expressly stated otherwise. Targets are engineering acceptance criteria,
not measured results. Four compartments are numbered 1–4 throughout.

## Minimum viable functional requirements

| ID | Requirement and acceptance criterion | Bootstrap status |
| --- | --- | --- |
| FR-01 | Store up to eight daily schedule entries (hour, minute, compartment); reject invalid entries, duplicates and overlapping windows, including across midnight. | Implemented; two example entries |
| FR-02 | Start each scheduled occurrence at most once per day during uninterrupted operation. Evaluate time at least once per second. | Implemented with manual simulated time |
| FR-03 | Indicate the active compartment using its LED, display text and audible reminder. Return outputs to idle after the outcome. | Output port and console representation only |
| FR-04 | Detect debounced open/closed transitions independently on all four compartments. Unchanged levels must not produce repeated events. | Fake levels and edge filtering; physical debounce pending |
| FR-05 | Record `ACCESS_CONFIRMED` only after the expected lid has remained open for the verification interval within its active window. Close before the interval restores the reminder. | Implemented |
| FR-06 | Warn and log a wrong-compartment opening without changing the target or extending the deadline. | Implemented |
| FR-07 | Record exactly one `MISSED` outcome when the window expires without confirmation; timeout wins at the exact deadline. | Implemented |
| FR-08 | Warn on a fresh opening of a previously confirmed compartment until its next accepted dose starts; call this repeated access, not confirmed double dosing. | Implemented; volatile history |
| FR-09 | Log timestamp, event, compartment, dose context, state, clock source and evidence type to serial in a machine-readable format. | Implemented; simulated seconds |
| FR-10 | Accept bounded serial commands for dose, lid and time injection without changing the domain implementation; reject malformed inputs. | Implemented on desktop and ESP32 |
| FR-11 | Support unscheduled and already-open lids: log unsolicited access; require close/reopen for a lid already open when its dose starts. | Implemented |
| FR-12 | Use a validated RTC for physical operation. Invalid/lost RTC time must inhibit scheduling and show a fault until explicitly set. | Physical integration pending |
| FR-13 | Provide a button to silence the audible reminder while keeping visual indication, deadline and access criteria active. A button must never mark a dose taken. | Physical integration pending |

## Minimum viable non-functional requirements

| ID | Requirement / acceptance criterion | Verification |
| --- | --- | --- |
| NFR-01 | Domain and simulation libraries compile without Arduino headers; application-owned state uses fixed storage and no explicit heap allocation. | Native build and code review |
| NFR-02 | Physical polling and outputs must avoid blocking delays; target response within 100 ms after a debounced lid edge. Scheduler resolution is one second. | H02 timing measurements; not yet measured |
| NFR-03 | Keep simultaneous active dose windows unsupported and explicitly reject conflicts rather than silently replacing a reminder. | T08, T10 |
| NFR-04 | Four compartments must have matching visible numbers, readable text and distinct warning/reminder patterns; information must not depend on color alone. | H05 scripted usability review |
| NFR-05 | Preserve CSV schema and record firmware revision, settings, clock mode and run ID in experiment metadata. No patient identity is required. | T15, capture review |
| NFR-06 | Core MVP operates offline from USB power; no cloud or network dependency. | H01 standalone operation |
| NFR-07 | Every minimum functional requirement has at least one planned test and an explicit implementation status. | Test-plan traceability review |
| NFR-08 | Retain a reproducible build configuration and automated tests; separate hardware results from simulation results. | Build workflow and validation record |

## Optional / stretch requirements

| ID | Requirement | Stage / acceptance idea |
| --- | --- | --- |
| FR-20 | Retain event history and completed occurrence IDs across reboot. | Level 2; restart does not duplicate a completed occurrence |
| FR-21 | Export logs through Wi-Fi and optionally notify a caregiver. | Level 2; local behavior unaffected by network outage |
| FR-22 | Add weight-change evidence through a load cell/HX711 verification adapter. | Level 3; compare against lid-only trials with measured ground truth |
| FR-23 | Provide a dashboard only if it supports useful review/configuration tasks. | Level 3; no dependency from reminder logic |
| NFR-20 | Improve physical durability with an enclosure and strain relief. | Level 2; repeat opening/cable-handling tests |
| NFR-21 | Produce a custom PCB after the breadboard design is stable. | Level 3; schematic review and repeat electrical tests |

## Explicit assumptions and exclusions

- One occurrence concerns one compartment. Simultaneous multi-compartment doses,
  prescription interpretation, dispensing and automatic locking are excluded.
- Simulation uses a 60 s window and 2 s verification. These values accelerate
  tests; the physical study must select and document suitable values. Switch
  debounce is separate from the longer access-verification interval.
- The first physical version uses fixed local time with explicit manual clock
  setup. Timezone/DST changes and backward time corrections during a running
  schedule require a future clock policy; they are not silently supported.
- Daily entries represent a laboratory test schedule, not clinical recommendations.
- No claim of ingestion detection, clinical validation, or prevention of overdose
  follows from a lid-open event, even if a lid remains open for two seconds.
- Course requirements listed here come from the supplied brief and should be
  reconciled with the instructor's exact rubric before final submission.
