# System architecture

## Blocks and dependency direction

```mermaid
flowchart LR
    Console[Desktop stdin or ESP32 serial] --> Sim[Simulation adapter and manual clock]
    Sim --> Fake[SimulatedLids]
    Fake --> Edge[Changed lid levels]
    RTC[Future validated DS3231 time adapter] -.-> Scheduler[MedicationScheduler]
    Sim --> Scheduler
    Reed[Future debounced reed-switch adapter] -.-> Edge
    Edge --> FSM[MedicationStateMachine]
    Scheduler --> FSM
    FSM --> Log[EventLogger port]
    FSM --> Output[ReminderController port]
    Log --> CSV[CsvLogger to TextOutput]
    Output --> FakeUI[SimulatedReminder to TextOutput]
    Output -.-> UI[Future LEDs buzzer OLED]
```

Solid paths are implemented; dashed paths are planned. The application depends
on C++ ports, not on GPIO, I2C, Arduino `Serial`, display libraries or Wi-Fi.

| Block | Responsibility | Owned data |
| --- | --- | --- |
| `MedicationScheduler` | Validate daily entries and emit a due occurrence once/day | Fixed eight-entry array and per-entry day watermark |
| `MedicationStateMachine` | Resolve access, verification, missed windows and warnings | Active dose, lid levels, verification start, per-lid repeated-access flags |
| `LidSensor` | Expose stable lid levels | Implemented by `SimulatedLids`; reed driver deferred |
| `EventLogger` | Consume structured domain events | CSV implementation writes immediately; no persistent storage |
| `ReminderController` | Present persistent state and transient warnings | Console implementation; physical output policy deferred |
| `Simulation` | Parse bounded commands, advance time and pass changed levels | 80-byte input buffer, manual clock, fake sensors |
| Entry points | Bind text input/output to the platform | Arduino `Serial` or standard input/output |

The domain takes time explicitly as an argument. A separate clock interface is
unnecessary at this stage. `Simulation` owns the only writable clock, and
`advance` accepts positive increments only. A physical composition root can later
pass RTC time and stable sensor edges into the same scheduler/FSM.

## Main operation

Each simulated second: advance time, tick the FSM to expire/confirm the active
window, then poll the scheduler. Lid commands update the fake sensor and publish
only changed levels. The FSM also ticks before handling a lid edge, so a lid
event cannot beat an already-expired deadline. Domain calls require
nondecreasing second timestamps; this is guaranteed by the simulation adapter.

The physical loop will validate the RTC, initialize actual lid levels **before**
polling the scheduler, debounce transitions, tick/poll, and update outputs without
long blocking delays. Read the RTC at an appropriate rate, rather than on every
CPU iteration. Long-running I/O must not be placed inside FSM transitions.

## Decisions

| Decision | Reason / consequence |
| --- | --- |
| Arduino + PlatformIO, `esp32dev`, C++17 | Small setup burden; no ESP-IDF-specific integration is needed yet |
| Three persistent states | Successful/missed outcomes and warnings are events, avoiding artificial delays and blocked reminders |
| Access rather than `TAKEN` | Naming matches what the lid sensor can actually establish |
| One active window, no queue | Simple deterministic MVP; overlapping configured windows rejected and injected conflicts logged |
| Fixed arrays and bounded command lines | Predictable application storage; no `String`, containers or explicit heap allocation in project code |
| Manual clock on both targets | Repeatable tests independent of wall time, RTC availability and terminal typing speed |
| Dwell filter before access confirmation | Rejects brief interactions, but cannot distinguish intentional access from a long accidental opening |
| Per-compartment repeat flag | A fresh reopening warns until that compartment's next accepted dose; no medication-dependent risk model |
| RAM-only schedule/history | Minimum bootstrap scope; reboot recovery remains an explicit limitation |
| Two libraries, no generic event bus | Keeps hardware-free logic reusable without a framework or speculative plugin system |

## Time, occurrence identity and recovery

A scheduled occurrence is identified by its absolute due second plus compartment
within the current run. Simulation day 0 has no calendar date. A scheduler poll
inside today's window starts the reminder with the **original** deadline. A poll
after today's window logs `MISSED`; it does not open a fresh window. The scheduler
does not reconstruct entirely skipped days. Simulation visits every second so
normal `advance` operations cannot skip them.

Booting the eventual physical firmware during a previously completed window
could duplicate that occurrence because history is volatile. Do not claim restart
recovery until FR-20 exists. A physical RTC-invalid state must gate the scheduler
(FR-12); the simulation currently assumes a valid artificial clock. The present
seconds-only design is not a complete DST/time-correction solution.

## Extension boundaries

1. Implement a reed-switch `LidSensor` with measured debounce, then feed its
   changed levels through `lidChanged` without modifying access rules.
2. Bind `ReminderController` to LEDs, buzzer and OLED. Add a silence-only button
   in the adapter and keep outcome logic untouched.
3. Supply validated RTC seconds and a deliberately selected window duration.
4. Add durable logging only after defining restart and occurrence identity rules.
5. Weight verification may replace the verification policy after experiments.
   No unused load-cell or networking abstraction is included now.

The port is a replacement boundary, not proof that any physical driver already
exists. Driver integration will need its own measurements and failure handling.
