# Medication state machine

## States and outcomes

`IDLE` has no active dose. `REMINDER` waits for a new opening of the intended lid.
`VERIFYING` waits for that lid to remain open for two seconds. `ACCESS_CONFIRMED`
and `MISSED` are terminal events followed immediately by `IDLE`.
`WRONG_COMPARTMENT` and `REPEATED_ACCESS` are warning events, not blocking states.

```mermaid
stateDiagram-v2
    [*] --> IDLE
    IDLE --> REMINDER: valid dose inside its window
    REMINDER --> VERIFYING: new correct-lid opening
    VERIFYING --> REMINDER: correct lid closes before dwell
    VERIFYING --> IDLE: dwell reached before deadline / ACCESS_CONFIRMED
    REMINDER --> IDLE: deadline reached / MISSED
    VERIFYING --> IDLE: deadline reached / MISSED
    REMINDER --> REMINDER: wrong lid / warning
    VERIFYING --> VERIFYING: wrong lid / warning
    IDLE --> IDLE: unsolicited or repeated opening / log
```

## Transition rules

Let `due` be the absolute due time, `deadline = due + 60 s`, and
`verified_at = correct_open_time + 2 s`. A valid confirmation requires
`verified_at <= now < deadline`. The two constants live in `Adherence.h`.

| Current state | Event / guard | Action | Next state |
| --- | --- | --- | --- |
| IDLE | Valid dose; due <= now < deadline | Select target, clear that lid's repeat flag, start outputs, log reminder | REMINDER |
| Any | Newly observed dose already expired | Log MISSED once for that occurrence; preserve any other active dose | Unchanged |
| Any active | Another dose, before expiry | Log DOSE_CONFLICT; retain original target/deadline | Unchanged |
| REMINDER | Fresh target opening | Save opening time, log verification start | VERIFYING |
| VERIFYING | Target closes before dwell | Log BRIEF_OPEN; retain original deadline | REMINDER |
| VERIFYING | Dwell reached before deadline | Log ACCESS_CONFIRMED; set repeat flag; clear outputs | IDLE |
| Any active | now >= deadline | Log MISSED; clear outputs | IDLE |
| Any active | Wrong lid opens | Log warning; do not restart verification or timeout | Unchanged |
| Any | A confirmed lid opens again | Log REPEATED_ACCESS and warn; if it is also the wrong active lid, log both warnings | Unchanged unless other rule applies |
| IDLE | Unconfirmed lid opens | Log UNSCHEDULED_OPEN | IDLE |
| Any | Unchanged lid level | Ignore duplicate edge | Unchanged |

Every changed level also emits `LID_OPEN` or `LID_CLOSED`. Closing a wrong lid
does not change the active state. Logs record state **at emission**, so the
terminal confirmation row says `VERIFYING`, and a timeout row shows the state
that expired; the subsequent output message shows `IDLE`.

## Ordering and exceptional cases

- **Timeout has priority.** At the exact deadline, a correct opening or a dwell
  completion cannot convert a missed dose to confirmed access.
- **Close exactly at dwell:** `tick` runs before the edge, so a lid held open for
  exactly two seconds confirms if still before the deadline.
- **Already open:** the lid must first close and reopen after the reminder starts.
  Keeping it open does not start verification. The current simulator starts with
  all lids closed; hardware must seed actual levels before scheduling.
- **Repeated opening:** duplicate `open` commands do nothing. Close/open is needed
  to represent a second interaction. The warning history is per compartment,
  survives other compartments' doses, and ends at its next accepted dose or reset.
- **Invalid input:** compartments outside 1–4, future injected due times, malformed
  commands and oversized lines are rejected without starting a dose. Invalid
  schedule entries are rejected when added.
- **Scheduling conflicts:** schedule windows cannot overlap, even across midnight.
  A manual test dose can conflict with a scheduled dose; the latter is logged as
  `DOSE_CONFLICT` once and is not queued/retried. This is a test diagnostic, not a
  missed outcome or confirmation. Avoid injections during schedule trials.
- **Polling late:** expire the previous dose first. An already-expired newly
  observed occurrence produces `MISSED` immediately.
- **Unsolicited lid held open:** still cannot be interpreted as pill removal.
  The dwell rule reduces short accidental confirmations; it cannot eliminate
  false confirmations from longer accidental interactions.
- **Reset / clock faults:** history is volatile. Fault gating and RTC setup belong
  to the pending hardware adapter; backward time is outside the domain contract.

The simulation is event driven with second resolution. Physical switch debounce
must precede these transitions; it must not be confused with two-second dwell.
