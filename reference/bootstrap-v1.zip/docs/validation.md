# Bootstrap validation — 2026-09-21

## Executed locally

| Check | Result |
| --- | --- |
| ESP32 firmware, PlatformIO 6.1.18, espressif32 6.10.0, Arduino | PASS; firmware.bin generated |
| 15 portable C++ tests, standalone runner | PASS, 15/15 |
| Desktop simulator compile | PASS |
| Wrong opening → correct access → repeated opening | PASS; expected event sequence and idle completion |
| CSV capture parsing | PASS; seven fields; repeated-access dose context retained |
| Fresh simulator `advance 120` | PASS; reminder at 28800, MISSED at 28860 |

ESP32 build reports 21,776 bytes static RAM and 271,333 bytes flash. These are
linker/build figures, not measurements of runtime stack usage or physical behavior.
Framework package resolved to `3.20017.241212+sha.dcc1105b` and Xtensa toolchain to
`8.4.0+2021r2-patch5`.

The host compiler was Zig 0.13.0's C++ frontend on Windows, installed locally
because GCC was unavailable. Project sources compiled as C++17 with
`-Wall -Wextra -Wpedantic -Werror`. The initial compiler-runtime build emitted
warnings within its bundled libunwind; project sources passed strict compilation.

## Reproduce in this workspace

PlatformIO and the portable compiler were placed in ignored `.tools/`; generated
host executables are in ignored `build/`. From the repository root in PowerShell:

```powershell
# Firmware (the downloaded toolchain is local to this workspace)
$env:PLATFORMIO_CORE_DIR = Join-Path $PWD '.tools\platformio'
& '.\.tools\venv\Scripts\pio.exe' run -e esp32dev

# Portable tests, with the exact same test functions used by the Unity runner
$env:ZIG_GLOBAL_CACHE_DIR = Join-Path $PWD '.tools\zig-cache'
& '.\.tools\venv\Lib\site-packages\ziglang\zig.exe' c++ -std=c++17 -Wall -Wextra -Wpedantic -Werror -DSTANDALONE_TEST -Ilib/Adherence/src -Ilib/Simulation/src lib/Adherence/src/Adherence.cpp lib/Simulation/src/Simulation.cpp test/test_domain/test_main.cpp -o build/domain-tests.exe
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
& '.\build\domain-tests.exe'

# Desktop simulator
& '.\.tools\venv\Lib\site-packages\ziglang\zig.exe' c++ -std=c++17 -Wall -Wextra -Wpedantic -Werror -Ilib/Adherence/src -Ilib/Simulation/src lib/Adherence/src/Adherence.cpp lib/Simulation/src/Simulation.cpp src/native_main.cpp -o build/simulator.exe
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
& '.\build\simulator.exe'
```

A fresh checkout uses the standard PlatformIO commands in the main README. The
local `.tools/` installation is convenience tooling and is not part of the source
distribution. The native PlatformIO/Unity runner and GitHub Actions workflow have
not been executed here; the same test functions were run with the standalone
assertion adapter instead. CI is configured to run the Unity path on Linux.

## Not yet validated

No firmware was uploaded to a physical ESP32. RTC operation, GPIO wiring,
electrical compatibility, switch debounce, sound/display output, power-loss
recovery and user interaction have not been experimentally evaluated. No
experimental data or clinical results are claimed by these software checks.
