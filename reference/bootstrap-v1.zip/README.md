# Smart Medication Adherence System

An instrumented four-compartment pill organizer that reminds a user, identifies
the intended compartment, and records access events. A Digital Systems Design
course project at **Politecnico di Milano**, developed as a small embedded-systems
portfolio project.

**Status: documentation and simulation bootstrap.** Portable C++ logic, an ESP32
Arduino serial adapter, a desktop simulator, and automated tests are implemented.
RTC, reed-switch, LED, buzzer, button and OLED drivers are planned, not implemented.
No hardware performance or clinical effectiveness has been measured.

The device does not dispense medication. In this first version, a sustained lid
opening is evidence of **compartment access**, not proof of pill removal or
ingestion. Repeated access is a warning, not a diagnosis of double dosing.

## Scope and stages

| Stage | Scope | Current status |
| --- | --- | --- |
| Bootstrap | Requirements, architecture, serial simulation, tests | Implemented |
| Level 1 | ESP32, RTC, four lids and LEDs, buzzer, button, OLED, daily schedule and serial logs | Domain logic ready; physical integration pending |
| Level 2 | Improved UI, enclosure, durable logging and optional connectivity | Planned |
| Level 3 | Optional load cell/HX711 comparison, PCB, refined mechanics and dashboard | Stretch |

The MVP prioritizes offline behavior and clear experimental evidence. Optional
features are not prerequisites for the course demonstration.

## Quick start

Install VS Code and the PlatformIO IDE extension, then open this folder. Use the
PlatformIO terminal for the commands below. Target: generic ESP32 Dev Module
(`esp32dev`), Arduino framework, C++17. Confirm the actual board before uploading.

```sh
pio run -e esp32dev
pio run -e esp32dev -t upload
pio device monitor -b 115200
```

No peripheral wiring is needed for this build. Send commands with a newline
(Enter). If startup text was missed, use `help` and `status`.

Without any ESP32, use a desktop C++ compiler on PATH (GCC/MinGW):

```sh
pio run -e native -t exec
pio test -e native
```

PlatformIO's native environment requires a separately installed host compiler;
see the [official native setup guide](https://docs.platformio.org/en/latest/platforms/native.html).
The [ESP32 board definition](https://docs.platformio.org/en/latest/boards/espressif32/esp32dev.html)
documents the selected target. CI builds both targets and runs native tests.

### Deterministic simulation

Time starts at simulation day 0, 07:59:00 and **moves only with `advance`**, on both
desktop and ESP32. This is deliberately not the final RTC-driven application.
The demo schedule is 08:00 compartment 2 and 20:00 compartment 4 each day. The
demo dose window is 60 seconds; verification requires two simulated seconds open.

```text
dose 2
open 3
open 2
advance 2
close 2
open 2
status
```

Expected key events: `REMINDER_STARTED`, `WRONG_COMPARTMENT`,
`VERIFICATION_STARTED`, `ACCESS_CONFIRMED`, `REPEATED_ACCESS`. Closing before two
seconds produces `BRIEF_OPEN` and keeps the reminder active. Restart the program
or reset the ESP32 between independent experiments.

| Command | Meaning |
| --- | --- |
| `dose N` | Inject a dose for compartment 1–4, due now; reject if busy |
| `open N`, `close N` | Set a simulated lid level; duplicate levels do not create edges |
| `advance S` | Advance 1–86400 seconds, visiting every second |
| `status` | Show simulated time, state, and active compartment |
| `help` | List commands |

To test a scheduled missed dose from a fresh launch, send `advance 120`.
The reminder starts at 28800 and is missed at 28860. Commands beginning with `#`
are not accepted; output lines beginning with `#` are explanatory comments.

## Repository structure

```text
├── README.md, LICENSE, .gitignore, platformio.ini
├── .github/workflows/build.yml      # native tests and both builds
├── .vscode/extensions.json          # PlatformIO recommendation
├── src/
│   ├── main.cpp                     # thin Arduino serial entry point
│   └── native_main.cpp              # desktop stdin entry point
├── include/                         # future board configuration
├── lib/
│   ├── Adherence/src/               # scheduler, domain FSM and ports
│   └── Simulation/src/              # serial protocol, fake lids and outputs
├── test/test_domain/                # hardware-independent C++ tests
├── docs/                            # requirements, design, tests, BOM, research
├── hardware/{schematics,pcb,datasheets}/
├── mechanical/{cad,renders}/
├── data/                            # experimental protocol and log schema
└── figures/                         # paper and presentation assets
```

Portable code lives in two PlatformIO libraries rather than `main.cpp`; a desktop
entry point makes progress possible before even the ESP32 arrives. A small CI
workflow makes build/test expectations reproducible. Directory READMEs document
future outputs without implying that designs already exist.

## Design and course deliverables

- [Requirements and scope](docs/requirements.md)
- [Architecture and decisions](docs/system_architecture.md)
- [State machine and edge cases](docs/state_machine.md)
- [Traceable experimental test plan](docs/test_plan.md)
- [Planned bill of materials](docs/bom.md)
- [Literature research worksheet](docs/literature_notes.md)
- [Course milestones and suggested Git commits](docs/development_plan.md)
- [Data schema and experiment capture](data/README.md)

The course outputs are an eight-page LaTeX paper, a five-minute pitch (about seven
slides), a working prototype, a 30-second video, code and experimental data. These
artifacts will be developed incrementally; this repository does not claim they
are complete. See [validation](docs/validation.md) for checks run on the bootstrap.

## Limitations

Schedules and history are currently RAM-only. Simulation timestamps are not UTC.
The scheduler assumes nondecreasing time and supports eight daily entries with
nonoverlapping windows. A reboot loses history; RTC validation, recovery after
power loss, switch debounce and physical outputs must be integrated before the
Level 1 demonstration. See the state-machine document for precise policies.

License selection is pending; see [LICENSE](LICENSE).
